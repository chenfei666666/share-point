package com.chen.learn.java8.functioninterface;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * 四大函数式接口
 */
public class FunctionInterface {

    @FunctionalInterface
    interface Test1 {
        void test();
        boolean equals(Object obj);
    }

    public static void main(String[] args) {
        /*
         * Consumer-消费型接口
         * void accept(T t);
         * 如stream API的forEach方法
         */
        Consumer<Integer> consumer = m -> System.out.println("消费了" + m);
        consumer.accept(1000);

        /*
         * Supplier-供给型接口
         * T get();
         * 产生指定个数的整数，并放入集合中
         * 如ThreadLocal的withInitial方法
         * 形似Spring的ObjectFactory
         */
        Supplier<Integer> supplier = () -> (int) (Math.random() * 100);
        supplier.get();
        List<Integer> numList = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            numList.add(supplier.get());
        }
        numList.forEach(System.out::println);

        /*
         * Function-函数型接口
         * R apply(T t);
         * 处理字符串
         * 如stream API的map方法
         */
        Function<String, String> fun = String::trim;
        String apply = fun.apply(" ab c d ");
        System.out.println(apply);

        /*
         * Predicate-断言型接口
         * boolean test(T t);
         * 处理字符串
         * 如stream API的filter方法
         */
        Predicate<String> pre = str -> str.contains("a");
        boolean test = pre.test("abc");
        System.out.println(test);

    }

}
