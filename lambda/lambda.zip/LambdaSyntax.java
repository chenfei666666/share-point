package com.chen.learn.java8.lambda;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Stream;

/**
 * @author chenfei
 * @date 2023/12/29 15:28
 * @description
 **/
public class LambdaSyntax {

    public static void main(String[] args) {
        // 引用类静态方法 类名::方法名
        // 如果有参数会把参数当方法的实参
        Stream<String> stringStream1 = Stream.of(1, 2).map(s -> String.valueOf(s));
        Stream<String> stringStream2 = Stream.of(1, 2).map(String::valueOf);

        // 引用对象的实例方法 对象名::方法名
        String str = "hello";
        Function<Integer, Character> charAtFunc = str::charAt;
        char firstChar = charAtFunc.apply(0);

        // 引用类的实例方法 类名::方法名
        // 把第一个参数当做类对象，用来调用 instance_method，其他参数当做方法的参数
        Stream<Integer> stringStream3 = Stream.of("1", "2").map(s -> s.length());
        Stream<Integer> stringStream4 = Stream.of("1", "2").map(String::length);

        // 构造器引用 类名::new
        Supplier<List<String>> listSupplier = ArrayList::new;
        List<String> newList = listSupplier.get();
    }

}
