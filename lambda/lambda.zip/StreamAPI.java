package com.chen.learn.java8.streamapi;

import com.chen.learn.java8.entity.Employee;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @Description
 * @Author chenfei
 * @Date 2023/12/29 15:38
 **/
public class StreamAPI {

    private final static List<Employee> employees = Arrays.asList(
            new Employee(1,"张三", 18, 9999.99),
            new Employee(2,"李四", 25, 5554.55),
            new Employee(3,"王五", 67, 2445.99),
            new Employee(4,"赵六", 43, 9098.99),
            new Employee(5,"田七", 54, 10982.99)
    );

    public static void main(String[] args) {

        //筛选与切片
        Stream<Employee> stream = employees.stream().filter((e) -> e.getAge() > 35);

        // 终止操作
        stream.forEach(System.out::println);
        System.out.println("---------------------------------------");

        //映射
        List<String> strs = Arrays.asList("aaa","bbb","ccc","ddd","eee");
        Stream<Character> characterStream = strs.stream().flatMap(StreamAPI::filterCharacter);
        characterStream.forEach(System.out::println);
        System.out.println("---------------------------------------");

        //排序
        /*
         * sorted()：自然排序
         * sorted(Comparator c)：定制排序
         */
        employees.stream().sorted((e1,e2) -> {
            if (e1.getAge() == e2.getAge()) {
                return e1.getName().compareTo(e2.getName());
            } else {
                return e1.getAge() - e2.getAge();
            }
        }).forEach(System.out::println);
        System.out.println("---------------------------------------");

        //查找/匹配
        List<Employee.Status> list = Arrays.asList(Employee.Status.FREE, Employee.Status.BUSY, Employee.Status.VACATION);

        boolean flag1 = list.stream()
                .allMatch((s) -> s.equals(Employee.Status.BUSY));
        System.out.println(flag1);

        boolean flag2 = list.stream()
                .anyMatch((s) -> s.equals(Employee.Status.BUSY));
        System.out.println(flag2);

        boolean flag3 = list.stream()
                .noneMatch((s) -> s.equals(Employee.Status.BUSY));
        System.out.println(flag3);
        System.out.println("---------------------------------------");

        // Optional避免空指针异常
        Optional<Employee.Status> op1 = list.stream()
                .findFirst();
        // 如果Optional为空 找一个替代的对象
        Employee.Status s1 = op1.orElse(Employee.Status.BUSY);
        System.out.println(s1);

        Optional<Employee.Status> op2 = list.stream().findAny();
        System.out.println(op2);
        System.out.println("---------------------------------------");

        //归约
        List<Integer> list1 = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
        Integer reduce = list1.stream().reduce(0, Integer::sum);
        System.out.println("reduce:" + reduce);

        Optional<Double> optional = employees.stream().map(Employee::getSalary).reduce(Double::sum);
        optional.ifPresent(System.out::println);
        System.out.println("---------------------------------------");

        //平均值
        Double avg = employees.stream()
                .collect(Collectors.averagingDouble(Employee::getSalary));
        System.out.println(avg);

        //总和
        Double sum = employees.stream().mapToDouble(Employee::getSalary).sum();
        System.out.println(sum);

        //最大值
        Optional<Employee> max = employees.stream().max(Comparator.comparingDouble(Employee::getSalary));
        max.ifPresent(System.out::println);

        //最小值
        Optional<Double> min = employees.stream().map(Employee::getSalary).min(Double::compare);
        min.ifPresent(System.out::println);

        System.out.println("---------------------------------------");

        //分组
        Map<Integer, List<Employee>> map = employees.stream()
                .collect(Collectors.groupingBy(Employee::getId));

        //多级分组
        Map<Integer, Map<String, List<Employee>>> mapMap = employees.stream()
                .collect(Collectors.groupingBy(Employee::getId, Collectors.groupingBy((e) -> {
                    if (e.getAge() > 35) {
                        return "开除";
                    } else {
                        return "继续加班";
                    }
                })));
        System.out.println("分组：" + mapMap);

        //分区
        Map<Boolean, List<Employee>> listMap = employees.stream()
                .collect(Collectors.partitioningBy((e) -> e.getSalary() > 4321));
        System.out.println("分区：" + listMap);

    }

    private static Stream<Character> filterCharacter(String str) {
        List<Character> list = new ArrayList<>();

        for (Character ch : str.toCharArray()) {
            list.add(ch);
        }
        return list.stream();
    }

}
